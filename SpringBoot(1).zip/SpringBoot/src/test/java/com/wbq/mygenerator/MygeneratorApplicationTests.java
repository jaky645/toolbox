package com.wbq.mygenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MygeneratorApplicationTests {

    @Test
    void contextLoads() {
    }

}
