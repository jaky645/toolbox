package com.wbq.mygenerator.mapper;

import com.wbq.mygenerator.entity.Dprequest;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * AP and DP request  Mapper 接口
 * </p>
 *
 * @author Baiqing Wu
 * @since 2021-11-11
 */
public interface DprequestMapper extends BaseMapper<Dprequest> {

}
