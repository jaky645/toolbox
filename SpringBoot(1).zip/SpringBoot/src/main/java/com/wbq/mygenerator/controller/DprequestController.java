package com.wbq.mygenerator.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * AP and DP request  前端控制器
 * </p>
 *
 * @author Baiqing Wu
 * @since 2021-11-11
 */
@RestController
@RequestMapping("/dprequest")
public class DprequestController {

}

