package com.wbq.mygenerator.service.impl;

import com.wbq.mygenerator.entity.Dprequest;
import com.wbq.mygenerator.mapper.DprequestMapper;
import com.wbq.mygenerator.service.DprequestService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * AP and DP request  服务实现类
 * </p>
 *
 * @author Baiqing Wu
 * @since 2021-11-11
 */
@Service
public class DprequestServiceImpl extends ServiceImpl<DprequestMapper, Dprequest> implements DprequestService {

}
