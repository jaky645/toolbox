package com.wbq.mygenerator.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * AP and DP request 
 * </p>
 *
 * @author Baiqing Wu
 * @since 2021-11-11
 */
@Data
  @EqualsAndHashCode(callSuper = false)
    @ApiModel(value="Dprequest对象", description="AP and DP request ")
public class Dprequest implements Serializable {

    private static final long serialVersionUID = 1L;

      @TableId(value = "DPRequestKey", type = IdType.AUTO)
      private Integer dprequestkey;

    @TableField("RequesterPhone")
    private String requesterphone;

    @TableField("RequesterFax")
    private String requesterfax;

    @TableField("RequesterHosp")
    private String requesterhosp;

    @TableField("RequesterEmail")
    private String requesteremail;

    @TableField("RManagerID")
    private String rmanagerid;

    @TableField("RManagerName")
    private String rmanagername;

    @TableField("RManagerTitle")
    private String rmanagertitle;

    @TableField("RManagerEmail")
    private String rmanageremail;

    @TableField("RManagerApprovalStatus")
    private String rmanagerapprovalstatus;

    @TableField("RManagerApprovalDate")
    private LocalDateTime rmanagerapprovaldate;

    @TableField("RManagerRemark")
    private String rmanagerremark;

    @TableField("ServiceType")
    private String servicetype;

    @TableField("ServiceAtHosp")
    private String serviceathosp;

    @TableField("TotalNumOfDP")
    private Integer totalnumofdp;

    @TableField("StartInstallDate1")
    private String startinstalldate1;

    @TableField("StartInstallDate2")
    private Integer startinstalldate2;

    @TableField("RequesterTitle")
    private String requestertitle;

    @TableField("RequesterID")
    private String requesterid;

    @TableField("RequesterName")
    private String requestername;

    @TableField("DPRequestID")
    private String dprequestid;

    @TableField("FormCreatedBy")
    private String formcreatedby;

    @TableField("RequestDate")
    private LocalDateTime requestdate;

    @TableField("SubmittedBy")
    private String submittedby;

    @TableField("SubmissionDate")
    private LocalDateTime submissiondate;

    @TableField("InstallTimePeriod")
    private String installtimeperiod;

    @TableField("ExpectedCompletionDate")
    private String expectedcompletiondate;

    @TableField("OtherServices")
    private String otherservices;

    @TableField("ApplyIP")
    private Boolean applyip;

    @TableField("Remark")
    private String remark;

    @TableField("RespStaff")
    private String respstaff;

    @TableField("MetallicCablingQty")
    private Integer metalliccablingqty;

    @TableField("PlasticCablingQty")
    private Integer plasticcablingqty;

    @TableField("NoConduitCablingQty")
    private Integer noconduitcablingqty;

    @TableField("HubPortQty")
    private Integer hubportqty;

    @TableField("ProjectBasedDPQty")
    private Integer projectbaseddpqty;

    @TableField("MetallicCablingCharge")
    private BigDecimal metalliccablingcharge;

    @TableField("PlasticCablingCharge")
    private BigDecimal plasticcablingcharge;

    @TableField("NoConduitCablingCharge")
    private BigDecimal noconduitcablingcharge;

    @TableField("HubPortCharge")
    private BigDecimal hubportcharge;

    @TableField("ProjectBasedDPCharge")
    private BigDecimal projectbaseddpcharge;

    @TableField("AdditionalCharge")
    private BigDecimal additionalcharge;

    @TableField("QuotationTotal")
    private BigDecimal quotationtotal;

    @TableField("QuotationStatus")
    private String quotationstatus;

    @TableField("QuotationUpdateDate")
    private LocalDateTime quotationupdatedate;

    @TableField("ACOMApprovalStatus")
    private String acomapprovalstatus;

    @TableField("ACOMApprovalDate")
    private LocalDateTime acomapprovaldate;

    @TableField("ACOMRemark")
    private String acomremark;

    @TableField("FundTransferredToHSTeam")
    private Integer fundtransferredtohsteam;

    @TableField("BudgetHolderID")
    private String budgetholderid;

    @TableField("BudgetHolderName")
    private String budgetholdername;

    @TableField("BudgetHolderTitle")
    private String budgetholdertitle;

    @TableField("BudgetHolderEmail")
    private String budgetholderemail;

    @TableField("BudgetHolderRemark")
    private String budgetholderremark;

    @TableField("FundParty")
    private String fundparty;

    @TableField("FundConfirmed")
    private BigDecimal fundconfirmed;

    @TableField("FundConfirmedStatus")
    private String fundconfirmedstatus;

    @TableField("FundConfirmedDate")
    private LocalDateTime fundconfirmeddate;

    @TableField("PaymentMethod")
    private String paymentmethod;

    @TableField("ChartOfAccount")
    private String chartofaccount;

    @TableField("OtherPaymentMethod")
    private String otherpaymentmethod;

    @TableField("ExtBillCompanyName")
    private String extbillcompanyname;

    @TableField("ExtBillCompanyAdd")
    private String extbillcompanyadd;

    @TableField("ExtBillContactName")
    private String extbillcontactname;

    @TableField("ExtBillContactPhone")
    private String extbillcontactphone;

    @TableField("AckSentBy")
    private String acksentby;

    @TableField("AckSentDate")
    private LocalDateTime acksentdate;

    @TableField("ArrangeSiteVisit")
    private String arrangesitevisit;

    @TableField("ArrangeSiteVisitDate")
    private String arrangesitevisitdate;

    @TableField("AdminRemark")
    private String adminremark;

    @TableField("DPRequestStatus")
    private String dprequeststatus;

    @TableField("JobCompletedDate")
    private LocalDateTime jobcompleteddate;

    @TableField("ConnectMedicalNet2HANet")
    private Integer connectmedicalnet2hanet;

    @TableField("LastUpdatedBy")
    private String lastupdatedby;

    @TableField("LastUpdatedDate")
    private LocalDateTime lastupdateddate;

    @TableField("InternalRemarks")
    private String internalremarks;

    @TableField("AppType")
    private String apptype;

    @TableField("LANPool")
    private Integer lanpool;

    @TableField("DeductReason")
    private String deductreason;

    @TableField("HospitalReference")
    private String hospitalreference;

    @TableField("FundTxMemoIssued")
    private Boolean fundtxmemoissued;

    @TableField("AssignmentDate")
    private LocalDateTime assignmentdate;

    @TableField("BudgetingFiscalYear")
    private String budgetingfiscalyear;

    @TableField("Primary_EEFY")
    private String primaryEefy;

    @TableField("Primary_EE")
    private BigDecimal primaryEe;

    @TableField("Secondary_EEFY")
    private String secondaryEefy;

    @TableField("Secondary_EE")
    private BigDecimal secondaryEe;

    @TableField("FeedbackComment")
    private String feedbackcomment;

    @TableField("FeedbackRating")
    private Integer feedbackrating;

    @TableField("FeedbackDate")
    private LocalDateTime feedbackdate;

    @TableField("FeedbackHandledDate")
    private LocalDateTime feedbackhandleddate;

    @TableField("FeedbackHandleBy")
    private String feedbackhandleby;


}
