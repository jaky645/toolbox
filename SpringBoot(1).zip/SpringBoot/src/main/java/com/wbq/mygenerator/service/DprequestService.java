package com.wbq.mygenerator.service;

import com.wbq.mygenerator.entity.Dprequest;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * AP and DP request  服务类
 * </p>
 *
 * @author Baiqing Wu
 * @since 2021-11-11
 */
public interface DprequestService extends IService<Dprequest> {

}
