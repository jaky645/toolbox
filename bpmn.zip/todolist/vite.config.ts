import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
// https://divotion.com/blog/how-to-configure-import-aliases-in-vite-typescript-and-jest

export default defineConfig({
  resolve: {
    alias: {
      src: path.resolve(__dirname, 'src'),
    },
  },
  plugins: [react()],
  assetsInclude: ['**/*.bpmn'], // https://cn.vitejs.dev/guide/assets.html
  test: {
    environment: 'jsdom',
    globals: true,
  },
})
