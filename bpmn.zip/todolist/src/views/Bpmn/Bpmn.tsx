import { FC, useEffect, useRef, useState } from 'react'
import BpmnModeler from 'bpmn-js/lib/Modeler'
import {
  BpmnPropertiesPanelModule,
  BpmnPropertiesProviderModule,
} from 'bpmn-js-properties-panel'
import camundaModdleDescriptor from 'camunda-bpmn-moddle/resources/camunda'
import { EditingTools } from './components/EditingTools/index'
import diagramXML from '../../mock/newDiagram.bpmn?raw'
import 'bpmn-js/dist/assets/diagram-js.css'
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn.css'
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-codes.css'
import 'bpmn-js/dist/assets/bpmn-js.css'
import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css'
import 'bpmn-js-properties-panel/dist/assets/properties-panel.css'
import './Bpmn.less'
import { Alert, Snackbar } from '@mui/material'
import { FormDialog } from './components/FormDialog/FormDialog'
import { CustomizedDialogs } from './components/CustomizedDialogs/CustomizedDialogs'

interface bpmnModelerProprs {
  importXML?: (xml: string, err: any) => void
  get?: (str: string) => {
    undo: () => void
    redo: () => void
  }
  saveSVG?: (option: any, dataErr: any) => void
  saveXML?: (option: any, dataErr: any) => void
  current: any
}

const openDiagram = async (bpmnModeler: any, xml: string) => {
  await bpmnModeler.importXML(xml)
}

const createNewDiagram = async (bpmnModeler: any) => {
  openDiagram(bpmnModeler, diagramXML)
  // 两个dom，要解决
}
const addEventBusListener = (bpmnModeler: any) => {
  const eventBus = bpmnModeler.get('eventBus') // 需要使用eventBus
  const eventTypes = ['element.changed'] // 需要监听的事件集合
  eventTypes.forEach(function (eventType) {
    eventBus.on(eventType, function (e) {
      bpmnModeler.saveXML({ format: true }, (err: any, data: any) => {
        console.log('err', err)
        localStorage.setItem('xmldata', data)
      })
    })
  })
}
const download = (type: string, data: any, name?: string) => {
  let dataTrack = ''
  const a = document.createElement('a')

  switch (type) {
    case 'xml':
      dataTrack = 'bpmn'
      break
    case 'svg':
      dataTrack = 'svg'
      break
    default:
      break
  }

  name = name ?? `diagram.${dataTrack}`

  a.setAttribute(
    'href',
    `data:application/bpmn20-xml;charset=UTF-8,${encodeURIComponent(data)}`
  )
  a.setAttribute('target', '_blank')
  a.setAttribute('dataTrack', `diagram:download-${dataTrack}`)
  a.setAttribute('download', name)

  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
}

export const Bpmn: FC = () => {
  const bpmnRef = useRef(null)
  const parentRef = useRef(null)
  const customizedDialogsRef = useRef<CustomizedDialogsRef>(null)
  const FormDialogRef = useRef<FormDialogRef>(null)
  const bpmnModelerRef = useRef<bpmnModelerProprs | null>(null)
  const [alert, setAlert] = useState({
    openAlert: false,
    alertMsg: '',
    alertType: 'error',
    openXmlDialog: false,
    xmlContent: '',
  })
  const showAlert = (msg: string, type: string = 'error') => {
    setAlert({
      ...alert,
      alertType: type,
      openAlert: true,
      alertMsg: msg,
    })
    setTimeout(() => {
      setAlert({
        ...alert,
        openAlert: false,
      })
    }, 3000)
  }

  // 渲染 xml 格式
  const renderDiagram = (xml: any, type?: string) => {
    bpmnModelerRef.current?.importXML?.(xml, (err: any) => {
      if (err !== null || err !== undefined) {
        console.log(err)
        console.log(xml)
      }
    })
  }

  // 后退
  const handleUndo = () => {
    bpmnModelerRef.current?.get?.('commandStack').undo()
  }

  // 前进
  const handleRedo = () => {
    bpmnModelerRef.current?.get?.('commandStack').redo()
  }

  // 导入 xml 文件
  const handleOpenFile = (e: any) => {
    if (e.target.files.length > 0) {
      const file = e.target.files[0]
      const reader = new FileReader()
      let data = ''
      reader.readAsText(file)
      reader.onload = function (event: any) {
        data = event.target.result
        renderDiagram(data, 'open')
      }
    }
  }

  // 下载 SVG 格式
  const handleDownloadSvg = () => {
    bpmnModelerRef.current?.saveSVG?.(
      { format: true },
      (err: any, data: any) => {
        console.log('err', err)
        download('svg', data)
      }
    )
  }

  // 下载 XML 格式
  const handleDownloadXml = () => {
    bpmnModelerRef.current?.saveXML?.(
      { format: true },
      (err: any, data: any) => {
        console.log('err', err)
        download('xml', data)
      }
    )
  }
  // 打开modal查看xml
  const handlePreview = () => {
    bpmnModelerRef.current?.saveXML?.(
      { format: true },
      (err: any, data: any) => {
        console.log('err', err)
        setAlert({
          ...alert,
          xmlContent: data,
        })
        customizedDialogsRef.current?.handleClickOpen()
      }
    )
  }

  // 保存
  const handleSave = () => {
    let bpmnXml = ''
    let svgXml = ''
    bpmnModelerRef.current?.saveXML?.(
      { format: true },
      (err: any, xml: any) => {
        console.log('err', err)
        bpmnXml = xml
      }
    )
    bpmnModelerRef.current?.saveSVG?.(
      { format: true },
      (err: any, data: any) => {
        console.log('err', err, data)
        svgXml = data
      }
    )
    FormDialogRef.current?.handleClickOpen()
  }

  // 接收submitDialog数据做处理
  const handleSubmitDialog = (values) => {
    let bpmnXml = ''
    bpmnModelerRef.current?.saveXML?.(
      { format: true },
      async (err: any, xml: any) => {
        bpmnXml = xml
        console.log(bpmnXml, err)
        // const forms = new FormData()
        // forms.append('deployment-name', values.deployment_name)
        // forms.append('deployment-source', 'Camunda Modeler')
        // forms.append('enable-duplicate-filtering', true)
        // forms.append('tenant-id', values.tenant_id)
        // // 模拟出一个文件
        // const blob = new Blob([bpmnXml], { type: 'text/xml' })
        // forms.append('diagram_1.bpmn', blob, 'diagram_1.bpmn')
        // try {
        //   const res = await $ajax(
        //     '/engine-rest/deployment/create',
        //     forms,
        //     'POST'
        //   )
        //   that.showAlert('发布成功', 'success')
        //   localStorage.setItem('deployment_name', values.deployment_name)
        //   localStorage.setItem('tenant_id', values.tenant_id)
        //   that.childForm.handleClose()
        //   console.log(res)
        // } catch (e) {
        //   that.showAlert(e, 'error')
        // }
      }
    )
  }
  useEffect(() => {
    bpmnModelerRef.current = new BpmnModeler({
      // container: '#js-canvas',
      container: bpmnRef.current,
      propertiesPanel: {
        // parent: '#js-properties-panel',
        parent: parentRef.current,
      },
      additionalModules: [
        BpmnPropertiesPanelModule,
        BpmnPropertiesProviderModule,
      ],
      moddleExtensions: {
        camunda: camundaModdleDescriptor,
      },
    })
    createNewDiagram(bpmnModelerRef.current)
    addEventBusListener(bpmnModelerRef.current)
  }, [])
  return (
    <div className="overflowBpmn" id="haha">
      <div className="content with-diagram" id="js-drop-zone">
        <div className="canvas" ref={bpmnRef} id="js-canvas"></div>
        <div
          className="properties-panel-parent"
          ref={parentRef}
          id="js-properties-panel"
        ></div>
        <EditingTools
          onOpenFIle={handleOpenFile}
          onUndo={handleUndo}
          onRedo={handleRedo}
          onSave={handleSave}
          onDownloadSvg={handleDownloadSvg}
          onDownloadXml={handleDownloadXml}
          onPreview={handlePreview}
        />
        <Snackbar
          open={alert.openAlert}
          autoHideDuration={6000}
          anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
        >
          <Alert severity={alert.alertType} sx={{ width: '100%' }}>
            {alert.alertMsg}
          </Alert>
        </Snackbar>
        <FormDialog handleForm={handleSubmitDialog} ref={FormDialogRef} />
        <CustomizedDialogs xml={alert.xmlContent} ref={customizedDialogsRef} />
      </div>
    </div>
  )
}
