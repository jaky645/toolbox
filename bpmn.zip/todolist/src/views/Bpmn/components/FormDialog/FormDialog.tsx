import {
  Dialog,
  DialogTitle,
  DialogContent,
  TextField,
  DialogActions,
  Button,
} from '@mui/material'
import {
  FC,
  forwardRef,
  ForwardRefRenderFunction,
  useEffect,
  useImperativeHandle,
  useState,
} from 'react'
import { host_camunda } from '../../../../apis/constant'

interface CustomizedDialogsProps {
  handleForm: (state: any) => void
}

const _FormDialog: ForwardRefRenderFunction<
  CustomizedDialogsRef,
  CustomizedDialogsProps
> = (props, ref) => {
  const [state, setState] = useState({
    open: false,
    deployment_name: localStorage.getItem('deployment_name') != null || '',
    tenant_id: localStorage.getItem('tenant_id') != null || '',
    host_camunda,
  })
  useEffect(() => {}, [])

  const handleClickOpen = () => {
    setState((state) => Object.assign({}, state, { open: true }))
  }

  const handleClose = () => {
    setState((state) => Object.assign({}, state, { open: false }))
  }
  const handleChange = (name: string) => {
    return (event: any) => {
      setState((state) =>
        Object.assign({}, state, {
          [name]: event.target.value,
        })
      )
    }
  }

  const handleSubmit = () => {
    // 这里应该先要验证，然后把数据转回给父组件处理
    props.handleForm(state)
  }

  useImperativeHandle(
    ref,
    () => ({
      handleClickOpen,
      handleClose,
    }),
    []
  )

  return (
    <>
      <div>
        <Dialog open={state.open} onClose={handleClose}>
          <DialogTitle>发布到后台</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              id="deployment-name"
              label="Deployment Name"
              type="text"
              fullWidth
              variant="standard"
              value={state.deployment_name}
              onChange={handleChange('deployment_name')}
            />
            <TextField
              margin="dense"
              id="tenant-id"
              label="Tenant ID"
              type="text"
              fullWidth
              variant="standard"
              value={state.tenant_id}
              onChange={handleChange('tenant_id')}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>取消</Button>
            <Button onClick={handleSubmit}>发布</Button>
          </DialogActions>
        </Dialog>
      </div>
    </>
  )
}

export const FormDialog = forwardRef(_FormDialog)
