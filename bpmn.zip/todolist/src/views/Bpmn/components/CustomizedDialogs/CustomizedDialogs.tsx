import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  styled,
} from '@mui/material'
import {
  FC,
  forwardRef,
  ForwardRefRenderFunction,
  useEffect,
  useImperativeHandle,
  useState,
} from 'react'
import { object, string } from 'yup'
import { host_camunda } from '../../../../apis/constant'

interface CustomizedDialogsProps {
  xml: string
}
interface BootstrapDialogTitleProps {
  children: any
  id: string
  onClose?: () => void
}

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuDialogActions-root': {
    padding: theme.spacing(1),
  },
}))

export const BootstrapDialogTitle: FC<BootstrapDialogTitleProps> = (props) => {
  const { children, onClose, ...other } = props

  return (
    <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
      {children}
      {onClose !== undefined ? (
        <IconButton
          aria-label="close"
          onClick={onClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        ></IconButton>
      ) : null}
    </DialogTitle>
  )
}

const _CustomizedDialogs: ForwardRefRenderFunction<
  CustomizedDialogsRef,
  CustomizedDialogsProps
> = (props, ref) => {
  const [open, setOpen] = useState(false)
  const handleClickOpen = () => {
    setOpen(true)
  }
  const handleClose = () => {
    console.log('关闭')
    setOpen(false)
  }
  useImperativeHandle(
    ref,
    () => ({
      handleClickOpen,
      handleClose,
    }),
    []
  )
  return (
    <>
      <div>
        <BootstrapDialog
          onClose={handleClose}
          aria-labelledby="customized-dialog-title"
          open={open}
        >
          <BootstrapDialogTitle
            id="customized-dialog-title"
            onClose={handleClose}
          >
            Xml
          </BootstrapDialogTitle>
          <DialogContent dividers>
            <pre>{props.xml}</pre>
          </DialogContent>
          <DialogActions>
            <Button autoFocus onClick={handleClose}>
              关闭
            </Button>
          </DialogActions>
        </BootstrapDialog>
      </div>
    </>
  )
}
export const CustomizedDialogs = forwardRef(_CustomizedDialogs)
