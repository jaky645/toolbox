import { FC, useRef } from 'react'
import styles from './EditingTools.module.less'
interface EditingToolsProps {
  onOpenFIle?: () => void
  onUndo?: () => void
  onRedo?: () => void
  onSave?: () => void
  onDownloadSvg?: () => void
  onDownloadXml?: () => void
  onPreview?: () => void
}
interface FileProps {
  click?: () => void
}
export const EditingTools: FC<EditingToolsProps> = ({
  onOpenFIle,
  onUndo,
  onRedo,
  onSave,
  onDownloadSvg,
  onDownloadXml,
  onPreview,
}) => {
  const fileRef = useRef<FileProps | null>(null)
  const handleOpen = () => {
    fileRef?.click()
  }
  return (
    <>
      <div className={styles.editingTools}>
        <ul className={styles.controlList}>
          <li className={`${styles.control} ${styles.line}`}>
            <input
              ref={fileRef}
              className="openFile"
              type="file"
              onChange={onOpenFIle}
            />
            <button type="button" title="打开BPMN文件" onClick={handleOpen}>
              <i className={styles.open} />
            </button>
          </li>

          <li className={styles.control}>
            <button type="button" title="撤销" onClick={onUndo}>
              <i className={styles.undo} />
            </button>
          </li>
          <li className={`${styles.control} ${styles.line}`}>
            <button type="button" title="恢复" onClick={onRedo}>
              <i className={styles.redo} />
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="下载BPMN文件" onClick={onDownloadXml}>
              <i className={styles.download} />
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="下载流程图片" onClick={onDownloadSvg}>
              <i className={styles.image} />
            </button>
          </li>

          <li className={styles.control}>
            <button type="button" title="查看流程xml" onClick={onPreview}>
              <i className={styles.preview} />
            </button>
          </li>
          <li className={styles.control}>
            <button type="button" title="保存流程" onClick={onSave}>
              <i className={styles.save} />
            </button>
          </li>
        </ul>
      </div>
    </>
  )
}
