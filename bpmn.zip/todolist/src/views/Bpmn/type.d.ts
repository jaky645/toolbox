interface CustomizedDialogsRef {
  handleClickOpen: () => void
  handleClose: () => void
}
interface FormDialogRef {
  handleClickOpen: () => void
  handleClose: () => void
}
