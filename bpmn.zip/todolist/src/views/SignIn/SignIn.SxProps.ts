import { SxProps, Theme } from '@mui/material'

export const bgGridSxProps: SxProps<Theme> = {
  backgroundImage: 'url(https://source.unsplash.com/random)',
  backgroundColor: (t) =>
    t.palette.mode === 'light' ? t.palette.grey[50] : t.palette.grey[900],
}
