import { createTheme, Grid, ThemeProvider } from '@mui/material'
import { FC } from 'react'
import { useNavigate } from 'react-router-dom'
import { signIn } from '../../apis/auth'
import { Background } from './components/Background'
import { Content } from './components/Content'

const theme = createTheme()

export const SignIn: FC = () => {
  const navigate = useNavigate()

  const handleSubmit = async (values: SignInRequest) => {
    const { data } = await signIn(values)
    console.log(data)
    localStorage.setItem('token', data.token)
    navigate('/')
  }

  return (
    <ThemeProvider theme={theme}>
      <Grid container component="main" className="h-screen">
        <Background />
        <Content onSubmit={handleSubmit} />
      </Grid>
    </ThemeProvider>
  )
}
