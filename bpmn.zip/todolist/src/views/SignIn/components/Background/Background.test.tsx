import { render, screen } from '@testing-library/react'
import { Background } from './Background'
import '@testing-library/jest-dom'

describe('Background.tsx', () => {
  it('should pass this canary test', () => {
    expect(true).toBe(true)
  })

  it('should render Background', () => {
    // ARRANGE
    render(<Background />)

    // ACT

    // ASSERT
    expect(screen.getByRole('background')).toBeInTheDocument()
    expect(screen.getByRole('background')).toHaveStyle(
      'background-image: url(https://source.unsplash.com/random)'
    )
  })
})
