import { Grid } from '@mui/material'
import { FC } from 'react'
import { bgGridSxProps } from './Background.SxProps'

export const Background: FC = () => {
  return (
    <Grid
      item
      xs={false}
      sm={4}
      md={7}
      role="background"
      sx={bgGridSxProps}
      className="bg-no-repeat bg-cover bg-center"
    />
  )
}
