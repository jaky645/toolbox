import LockOutlinedIcon from '@mui/icons-material/LockOutlined'
import { Avatar, Box, Grid, Paper, Typography } from '@mui/material'
import { FC } from 'react'
import { Form } from '../Form'

interface ContentProps {
  onSubmit: (values: SignInRequest) => void
}

export const Content: FC<ContentProps> = ({ onSubmit }) => {
  return (
    <Grid item xs={12} sm={8} md={5} component={Paper} elevation={6} square>
      <Box
        sx={{
          my: 8,
          mx: 4,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Avatar className="m-2 bg" sx={{ bgcolor: 'secondary.main' }}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          Sign in
        </Typography>
        <Form onSubmit={onSubmit} />
      </Box>
    </Grid>
  )
}
