import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  TextField,
} from '@mui/material'
import { useFormik } from 'formik'
import { FC } from 'react'
import { FormHelper } from './FormHelper'
import { validationSchema } from './FormValidationSchema'

interface FormValue extends SignInRequest {}

interface FormProps {
  onSubmit: (values: SignInRequest) => void
}

export const Form: FC<FormProps> = ({ onSubmit }) => {
  const formik = useFormik<FormValue>({
    onSubmit,
    validationSchema,
    initialValues: { email: '', password: '' },
    validateOnBlur: true,
  })

  return (
    <Box
      component="form"
      noValidate
      className="mt-2"
      onSubmit={formik.handleSubmit}
    >
      <TextField
        margin="normal"
        required
        fullWidth
        autoFocus
        id="email"
        name="email"
        autoComplete="email"
        label="Email Address"
        value={formik.values.email}
        onBlur={formik.handleBlur}
        onChange={formik.handleChange}
        error={(formik.touched.email ?? false) && Boolean(formik.errors.email)}
        helperText={(formik.touched.email ?? false) && formik.errors.email}
      />
      <TextField
        margin="normal"
        required
        fullWidth
        name="password"
        label="Password"
        type="password"
        id="password"
        autoComplete="current-password"
        value={formik.values.password}
        onBlur={formik.handleBlur}
        onChange={formik.handleChange}
        error={
          (formik.touched.password ?? false) && Boolean(formik.errors.password)
        }
        helperText={
          (formik.touched.password ?? false) && formik.errors.password
        }
      />
      <FormControlLabel
        control={<Checkbox value="remember" color="primary" />}
        label="Remember me"
      />
      <Button type="submit" fullWidth variant="contained" className="mt-6 mb-4">
        Sign In
      </Button>
      <FormHelper />
    </Box>
  )
}
