import {
  Avatar,
  Box,
  Checkbox,
  FormControlLabel,
  FormGroup,
  Grid,
  IconButton,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Typography,
  List,
  styled,
} from '@mui/material'
import DeleteIcon from '@mui/icons-material/Delete'
import FolderIcon from '@mui/icons-material/Folder'
import EditIcon from '@mui/icons-material/Edit'
import React, { FC, useEffect, useState } from 'react'

import { getAppList } from '../../apis/auth'

const Demo = styled('div')(({ theme }) => ({
  backgroundColor: theme.palette.background.paper,
}))

export const AppList: FC = () => {
  const [secondary, setSecondary] = useState(true)
  const [appList, setAppList] = useState<GetAppListResponse>([])
  useEffect(() => {
    ;(async () => {
      const { data } = await getAppList()
      setAppList(data)
    })()
  }, [])
  const handleDelete = (id: number) => {
    const newList = appList.filter((item) => item.id !== id)
    setAppList(newList)
  }

  return (
    <Box sx={{ flexGrow: 1, maxWidth: 752 }}>
      <FormGroup row>
        <FormControlLabel
          control={
            <Checkbox
              checked={secondary}
              onChange={(event) => setSecondary(event.target.checked)}
            />
          }
          label="Enable secondary text"
        />
      </FormGroup>
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          <Typography sx={{ mt: 4, mb: 2 }} variant="h6" component="div">
            Avatar with text and icon
          </Typography>
          <Demo>
            <List dense={false}>
              {appList.map((item) => {
                return (
                  <ListItem
                    key={item.id}
                    secondaryAction={
                      <div>
                        <IconButton
                          edge="end"
                          aria-label="delete"
                          sx={{ mr: 1 }}
                          onClick={() => handleDelete(item.id)}
                        >
                          <DeleteIcon />
                        </IconButton>
                        {/* <IconButton edge="end" aria-label="delete">
                          <EditIcon />
                        </IconButton> */}
                      </div>
                    }
                  >
                    <ListItemAvatar>
                      <Avatar>
                        <FolderIcon />
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={item.content}
                      secondary={secondary ? item.describe : null}
                    />
                  </ListItem>
                )
              })}
            </List>
          </Demo>
        </Grid>
      </Grid>
    </Box>
  )
}
