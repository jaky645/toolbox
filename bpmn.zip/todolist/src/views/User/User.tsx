import {
  Box,
  Button,
  Checkbox,
  FormControl,
  FormControlLabel,
  FormGroup,
  FormHelperText,
  FormLabel,
  Grid,
  InputLabel,
  MenuItem,
  Radio,
  RadioGroup,
  Select,
  Snackbar,
  SnackbarOrigin,
  TextField,
  Typography,
} from '@mui/material'
import React, { FC, useState } from 'react'
import { useFormik } from 'formik'
import { validationSchema } from './FormValidationSchema'

export interface State extends SnackbarOrigin {
  open: boolean
}
interface FormValue extends UserRequest {}
export const User: FC = () => {
  const [state, setState] = useState<State>({
    open: false,
    vertical: 'top',
    horizontal: 'center',
  })
  const { vertical, horizontal, open } = state
  const handleClick = (newState: SnackbarOrigin) => () => {
    setState({ open: true, ...newState })
  }
  const handleClose = () => {
    setState({ ...state, open: false })
  }

  const onSubmit = () => {
    handleClick({
      vertical: 'top',
      horizontal: 'center',
    })
  }
  const formik = useFormik<FormValue>({
    onSubmit,
    validationSchema,
    initialValues: {
      email: '',
      password: '',
      gilad: false,
      jason: false,
      antoine: true,
      gender: '',
      language: 10,
      description: '',
    },
    validateOnBlur: true,
  })
  const checkboxError =
    [formik.values.gilad, formik.values.jason, formik.values.antoine].filter(
      (v) => v
    ).length === 0

  return (
    <React.Fragment>
      <Box
        component="form"
        noValidate
        className="mt-2"
        onSubmit={formik.handleSubmit}
      >
        <Typography variant="h6" gutterBottom>
          Personal information
        </Typography>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={6}>
            <TextField
              margin="normal"
              required
              fullWidth
              autoFocus
              id="email"
              name="email"
              autoComplete="email"
              label="Email Address"
              value={formik.values.email}
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              error={
                (formik.touched.email ?? false) && Boolean(formik.errors.email)
              }
              helperText={
                (formik.touched.email ?? false) && formik.errors.email
              }
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              margin="normal"
              required
              fullWidth
              name="password"
              label="Password"
              type="password"
              id="password"
              autoComplete="current-password"
              value={formik.values.password}
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              error={
                (formik.touched.password ?? false) &&
                Boolean(formik.errors.password)
              }
              helperText={
                (formik.touched.password ?? false) && formik.errors.password
              }
            />
          </Grid>
          <Grid item xs={12}>
            <FormControl
              error={
                (formik.touched.gender ?? false) &&
                Boolean(formik.errors.gender)
              }
            >
              <FormLabel id="demo-row-radio-buttons-group-label">
                Gender
              </FormLabel>
              <RadioGroup
                row
                aria-labelledby="demo-row-radio-buttons-group-label"
                name="gender"
                defaultValue="female"
                value={formik.values.gender}
                onChange={formik.handleChange}
              >
                <FormControlLabel
                  value="female"
                  control={<Radio />}
                  label="Female"
                />
                <FormControlLabel
                  value="male"
                  control={<Radio />}
                  label="Male"
                />
              </RadioGroup>
              <FormHelperText>
                {(formik.touched.gender ?? false) && formik.errors.gender}
              </FormHelperText>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <Box sx={{ display: 'flex' }}>
              <FormControl
                component="fieldset"
                variant="standard"
                error={checkboxError}
              >
                <FormLabel component="legend">Assign responsibility</FormLabel>
                <FormGroup>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.gilad}
                        onChange={formik.handleChange}
                        name="gilad"
                      />
                    }
                    label="Gilad Gray"
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.jason}
                        onChange={formik.handleChange}
                        name="jason"
                      />
                    }
                    label="Jason Killian"
                  />
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={formik.values.antoine}
                        onChange={formik.handleChange}
                        name="antoine"
                      />
                    }
                    label="Antoine Llorca"
                  />
                </FormGroup>
                <FormHelperText>
                  {(checkboxError ?? false) &&
                    'Assign responsibility is required'}
                </FormHelperText>
              </FormControl>
            </Box>
          </Grid>
          <Grid item xs={6}>
            <FormControl
              fullWidth
              error={
                (formik.touched.language ?? false) &&
                Boolean(formik.errors.language)
              }
            >
              <InputLabel id="demo-simple-select-readonly-label">
                Language
              </InputLabel>
              <Select
                labelId="demo-simple-select-readonly-label"
                id="language"
                name="language"
                value={formik.values.language}
                label="Language"
                onChange={formik.handleChange}
              >
                <MenuItem value="">
                  <em>None</em>
                </MenuItem>
                <MenuItem value={10}>English</MenuItem>
                <MenuItem value={20}>简体中文</MenuItem>
                <MenuItem value={30}>日本語</MenuItem>
              </Select>
              <FormHelperText>
                {(formik.touched.language ?? false) && formik.errors.language}
              </FormHelperText>
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <Grid item xs={6}>
              <TextField
                name="description"
                id="description"
                label="Description"
                multiline
                rows={4}
                className="w-full"
                value={formik.values.description}
                onChange={formik.handleChange}
                error={
                  (formik.touched.description ?? false) &&
                  Boolean(formik.errors.description)
                }
                helperText={
                  (formik.touched.description ?? false) &&
                  formik.errors.description
                }
              />
            </Grid>
          </Grid>
          <Button
            type="submit"
            fullWidth
            variant="contained"
            className="mt-6 mb-4"
          >
            submit
          </Button>
        </Grid>
      </Box>
      <Snackbar
        anchorOrigin={{ vertical, horizontal }}
        open={open}
        onClose={handleClose}
        message="Update succeeded"
        key={vertical + horizontal}
      />
    </React.Fragment>
  )
}
