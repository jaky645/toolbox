import * as yup from 'yup'

export const validationSchema = yup.object({
  email: yup
    .string()
    .email('Enter a valid email')
    .required('Email is required'),
  password: yup
    .string()
    .min(8, 'Password should be of minimum 8 characters length')
    .required('Password is required'),
  gender: yup.string().required('Gender is required'),
  language: yup.string().required('Lnguage is required'),
  description: yup
    .string()
    .min(10, 'Description should be of minimum 10 characters length')
    .required('Description is required'),
  // phone: yup.string().required('Phone is required').matches(/\d+/, ''),
})
