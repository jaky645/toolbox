import { Copyright } from '@mui/icons-material'
import { Box, Container, Toolbar } from '@mui/material'
import { FC, useEffect, useState } from 'react'
import { getProfile } from '../../apis/auth'
import { AppBar } from './components/AppBar'
import { Drawer } from './components/Drawer'
import { Outlet, useNavigate } from 'react-router-dom'
import style from './Home.module.less'

export const Home: FC = () => {
  const navigate = useNavigate()
  useEffect(() => {
    const token = localStorage.getItem('token')
    console.log('token', token)
    if (token != null) {
      ;(async () => {
        const { data } = await getProfile()
        console.log(data)
      })()
    } else {
      navigate('/sign-in')
    }
  }, [])
  const [open, setOpen] = useState(true)
  const toggleDrawer = () => {
    setOpen(!open)
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <AppBar position="absolute" open={open} onToggleDeawer={toggleDrawer} />
      <Drawer open={open} onToggleDeawer={toggleDrawer} />
      <Box
        component="main"
        sx={{
          backgroundColor: (theme) =>
            theme.palette.mode === 'light'
              ? theme.palette.grey[100]
              : theme.palette.grey[900],
          flexGrow: 1,
          height: '100vh',
          overflow: 'auto',
        }}
      >
        <Toolbar />
        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
          <Copyright sx={{ pt: 4 }} />
          <div className={style.outLetClass}>
            <Outlet />
          </div>
        </Container>
      </Box>
    </Box>
  )
}
