import {
  AppBar as MuiAppBar,
  AppBarProps as MuiAppBarProps,
  Badge,
  IconButton,
  Toolbar,
  Typography,
} from '@mui/material'
import { FC } from 'react'
import { getAppBarSxProps } from './AppBar.SxProps'
import MenuIcon from '@mui/icons-material/Menu'
import NotificationsIcon from '@mui/icons-material/Notifications'

interface AppBarProps extends MuiAppBarProps {
  open?: boolean
  onToggleDeawer?: () => void
}

export const AppBar: FC<AppBarProps> = ({ open, onToggleDeawer }) => {
  return (
    <MuiAppBar sx={getAppBarSxProps(open)}>
      <Toolbar
        sx={{
          pr: '24px', // keep right padding when drawer closed
        }}
      >
        <IconButton
          edge="start"
          color="inherit"
          aria-label="open drawer"
          onClick={onToggleDeawer}
          sx={{
            marginRight: '36px',
            ...((open ?? false) && { display: 'none' }),
          }}
        >
          <MenuIcon />
        </IconButton>
        <Typography
          component="h1"
          variant="h6"
          color="inherit"
          noWrap
          sx={{ flexGrow: 1 }}
        >
          Dashboard
        </Typography>
        <IconButton color="inherit">
          <Badge badgeContent={4} color="secondary">
            <NotificationsIcon />
          </Badge>
        </IconButton>
      </Toolbar>
    </MuiAppBar>
  )
}
