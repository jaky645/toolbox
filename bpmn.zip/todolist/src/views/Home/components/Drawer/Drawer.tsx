import ChevronLeftIcon from '@mui/icons-material/ChevronLeft'
import FormatListNumberedRtlIcon from '@mui/icons-material/FormatListNumbered'
import CropFreeIcon from '@mui/icons-material/CropFree'
import LayersIcon from '@mui/icons-material/Layers'
import {
  Divider,
  Drawer as MuiDrawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
} from '@mui/material'
import { FC } from 'react'
import { Link } from 'react-router-dom'
import { getDrawerSxProps } from './Drawer.SxProps'
interface DrawerProps {
  open?: boolean
  onToggleDeawer?: () => void
}

export const Drawer: FC<DrawerProps> = ({ open, onToggleDeawer }) => {
  return (
    <MuiDrawer variant="permanent" open={open} sx={getDrawerSxProps(open)}>
      <Toolbar
        sx={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'flex-end',
          px: [1],
        }}
      >
        <IconButton onClick={onToggleDeawer}>
          <ChevronLeftIcon />
        </IconButton>
      </Toolbar>
      <Divider />
      <List component="nav">
        <Link to="/list">
          <ListItemButton>
            <ListItemIcon>
              <FormatListNumberedRtlIcon />
            </ListItemIcon>
            <ListItemText primary="List" />
          </ListItemButton>
        </Link>
        <Link to="/user">
          <ListItemButton>
            <ListItemIcon>
              <LayersIcon />
            </ListItemIcon>
            <ListItemText primary="User" />
          </ListItemButton>
        </Link>
        <Link to="/bpmn">
          <ListItemButton>
            <ListItemIcon>
              <CropFreeIcon />
            </ListItemIcon>
            <ListItemText primary="Bpmn" />
          </ListItemButton>
        </Link>
      </List>
    </MuiDrawer>
  )
}
