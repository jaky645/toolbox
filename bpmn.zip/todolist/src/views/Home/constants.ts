export const drawerWidth = 240
