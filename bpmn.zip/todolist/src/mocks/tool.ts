import { AxiosResponse } from 'axios'
import Mock, { MockjsRequestOptions } from 'mockjs'

type Fn<R = any> = (params: any) => R

interface ApiFn<R> extends Fn<R> {
  url: string
}

type MockFnReturnType<T> = T extends Promise<AxiosResponse<infer R>>
  ? R | Promise<R>
  : never

type MockFn<T> =
  | (() => MockFnReturnType<T>)
  | ((options: MockjsRequestOptions) => MockFnReturnType<T>)

export const mockApi = <R>(api: ApiFn<R>, mock: MockFn<R>) => {
  return Mock.mock(api.url, mock)
}
