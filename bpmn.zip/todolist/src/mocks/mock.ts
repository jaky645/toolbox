import { mockGetProfile, mockSignIn, mockGetAppList } from './auth'

export const enableMock = () => {
  mockSignIn()
  mockGetProfile()
  mockGetAppList()
}
