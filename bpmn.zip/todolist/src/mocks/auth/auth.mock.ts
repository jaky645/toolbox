import { InsertEmoticon } from '@mui/icons-material'
import { KJUR } from 'jsrsasign'
import Mock from 'mockjs'
import { getProfile, signIn, getAppList } from 'src/apis/auth'
import { mockApi } from '../tool'

export const mockSignIn = () => {
  return mockApi(signIn, ({ body }) => {
    const sHead = { alg: 'HS256', cty: 'JWT' }
    const privateKey = import.meta.env.VITE_JWT_KEY
    const token = KJUR.jws.JWS.sign(null, sHead, JSON.parse(body), privateKey)

    return { token }
  })
}

export const mockGetProfile = () => {
  mockApi(getProfile, () => {
    const token = localStorage.getItem('token') ?? ''
    const { email } = KJUR.jws.JWS.parse(token).payloadObj as SignInRequest

    return { email, name: Mock.Random.string() }
  })
}

export const mockGetAppList = () => {
  mockApi(getAppList, () => {
    const appList = Array(20)
      .fill(null)
      .map((_, idx) => {
        return {
          time: new Date().getTime(),
          id: idx,
          content: Mock.Random.string(),
          describe: Mock.Random.string(),
        }
      })
    return appList
  })
}
