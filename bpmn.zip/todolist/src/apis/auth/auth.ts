import { axios } from '../axios.config'

const factory = <P extends any[], R>(
  url: string,
  request: (url: string, ...rest: P) => R
) => {
  const fn = (...data: P) => {
    return request(url, ...data)
  }
  fn.url = url.includes('http')
    ? url
    : `${import.meta.env.VITE_API_BASE_URL}${url}`

  return fn
}

export const signIn = factory('/signIn', (url, data: SignInRequest) => {
  return axios.post<SignInResponse>(url, data)
})

export const getProfile = factory('/profile', (url) =>
  axios.get<GetProfileResponse>(url)
)
export const getAppList = factory('/appList', (url) =>
  axios.get<GetAppListResponse>(url)
)
