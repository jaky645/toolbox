interface SignInRequest {
  email: string
  password: string
}

interface SignInResponse {
  token: string
}

interface GetProfileResponse {
  email: string
  name: string
}
interface AppListItem {
  time: number
  id: number
  content: string
  describe: string
}
type GetAppListResponse = AppListItem[]

interface UserRequest {
  email: string
  password: string
  gilad: boolean
  jason: boolean
  antoine: boolean
  gender: string
  description: string
  language: number
}
