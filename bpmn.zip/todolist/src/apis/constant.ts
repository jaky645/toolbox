// eslint-disable-next-line @typescript-eslint/naming-convention
export const host_camunda = 'http://10.240.131.123:3006/engine-rest'
// eslint-disable-next-line @typescript-eslint/naming-convention
export const tenant_id = ''
