import { CssBaseline } from '@mui/material'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import { Home } from './views/Home'
import { SignIn } from './views/SignIn'
import { AppList } from './views/List'
import { User } from './views/User'
import { Bpmn } from './views/Bpmn'
import { AppContent } from './views/Home/components/AppContent'

function App(): JSX.Element {
  return (
    <>
      <CssBaseline />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />}>
            <Route path="" element={<AppContent />} />
            <Route path="list" element={<AppList />} />
            <Route path="user" element={<User />} />
            <Route path="bpmn" element={<Bpmn />} />
          </Route>
          <Route path="/sign-in" element={<SignIn />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
