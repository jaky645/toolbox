import { SxProps, Theme } from '@mui/material'

type SP = SxProps<Theme>
